const API_URL="http://127.0.0.1:8000";
const input=document.getElementById("mediaFile");
const button=document.getElementById("analyzeBtn");
const status=document.getElementById("status");
const results=document.getElementById("results");
const uploadBoxLabel=document.getElementById("uploadBoxLabel");
const previewWrap=document.getElementById("previewWrap");
const previewImg=document.getElementById("previewImg");
const resultImg=document.getElementById("resultImg");

console.log("[MediaTrace] script.js loaded.");

input.onchange=()=>{
  const file=input.files[0];
  console.log("[MediaTrace] input changed. file:",file);
  if(!file)return;

  status.textContent="Selected: "+file.name;

  // Show the image preview in the center, hide the empty upload box
  const url=URL.createObjectURL(file);
  previewImg.src=url;
  previewWrap.classList.remove("hidden");
  uploadBoxLabel.classList.add("hidden");
};

button.onclick=async()=>{
  const file=input.files[0];
  console.log("[MediaTrace] button clicked. file:",file);
  if(!file){status.textContent="Please select an image first.";return}
  const fd=new FormData(); fd.append("file",file);
  button.disabled=true; button.textContent="Analyzing...";
  status.textContent="Uploading and analyzing...";
  try{
    const res=await fetch(API_URL+"/analyze",{method:"POST",body:fd});
    if(!res.ok)throw Error("Backend error");
    const d=await res.json();
    console.log("[MediaTrace] response:",d);
    if(d.error){status.textContent=d.error;return}
    resultImg.src=previewImg.src;
    render(d);
    status.textContent="Analysis complete.";
  }catch(e){
    console.error("[MediaTrace] error:",e);
    status.textContent="Backend not reachable. Start FastAPI on port 8000.";
  }finally{button.disabled=false;button.textContent="Analyze Media"}
};

function render(d){
  results.classList.remove("hidden");
  document.getElementById("score").textContent=d.ai_probability+"%";
  document.getElementById("ring").textContent=d.ai_probability+"%";
  document.getElementById("classification").textContent=d.classification;

  const signals=document.getElementById("signals");signals.innerHTML="";
  d.forensics.signals.forEach(s=>{
    const x=document.createElement("div");x.className="signal";x.textContent="⚠ "+s;signals.appendChild(x);
  });
  if(d.model){
    const x=document.createElement("div");x.className="signal";
    x.textContent="🤖 Model: "+d.model.name;
    signals.appendChild(x);
  }

  document.getElementById("sourceTrace").innerHTML=
    `<div class="signal"><strong>${d.source_trace.status}</strong></div>
     <div class="signal">Matches found: ${d.source_trace.matches_found}</div>
     <div class="signal">${d.source_trace.message}</div>`;

  document.getElementById("metadata").innerHTML=
    row("Filename",d.filename)+row("Media Type",d.media_type||"Unknown")+
    row("Format",d.forensics.format)+
    row("Dimensions",`${d.forensics.width} × ${d.forensics.height}`)+
    row("SHA-256",d.forensics.sha256);
}
function row(a,b){return `<div class="meta-row"><span>${a}</span><strong>${esc(b)}</strong></div>`}
function esc(v){return String(v).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;")}
