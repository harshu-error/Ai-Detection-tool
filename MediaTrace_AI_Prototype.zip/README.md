# MediaTrace AI

## 1. Backend
Open terminal in `backend`:

Windows:
`python -m venv .venv`
`.venv\Scripts\activate`
`pip install -r requirements.txt`
`uvicorn main:app --reload`

API: http://127.0.0.1:8000
Docs: http://127.0.0.1:8000/docs

## 2. Frontend
Open `frontend/index.html` with VS Code Live Server.

The frontend calls `POST http://127.0.0.1:8000/analyze`.

## AI Model
`/analyze` now runs a real pretrained deepfake detector — `prithivMLmods/Deep-Fake-Detector-v2-Model`
(Vision Transformer, fine-tuned on real vs. deepfake images, ~92% accuracy on its test set).
It's loaded once from Hugging Face when the FastAPI server starts (`pip install` will pull
`torch` + `transformers`, and the first server start downloads the model weights — needs
internet once, then it's cached locally in `~/.cache/huggingface`).

Notes for the hackathon:
- This model is trained mainly on **faces**. It's a strong baseline but will be weaker on
  non-face AI-generated images (landscapes, objects, art). If you need broader coverage,
  swap `MODEL_NAME` in `backend/main.py` for a general AI-image detector.
- `source_trace` is still a placeholder — that's the next piece to build (reverse image
  search / provenance database).
- First request after server start can take a few seconds while the model loads; subsequent
  requests are fast.
