# MediaTrace AI Forensic Suite v2.0

**MediaTrace AI** is a state-of-the-art AI image verification, Error Level Analysis (ELA) heatmap visualizer, and digital media source tracing suite.

---

## 🌟 Key Features

1. **AI Synthetic Image Detection**:
   - Deepfake classification using PyTorch / Hugging Face Vision Transformers (`prithivMLmods/Deep-Fake-Detector-v2-Model`).
   - Non-blocking async loading with automatic fallback to statistical texture & noise variance forensic engine.

2. **Interactive Error Level Analysis (ELA)**:
   - Computes pixel-by-pixel compression discrepancies resaved at 90% JPEG quality.
   - High-contrast visual overlay map highlights spliced or AI-generated regions.

3. **Multi-Signal Digital Forensics**:
   - Detailed EXIF camera metadata, GPS, and software tag extraction.
   - Perceptual image hashing (`dHash`) & SHA-256 cryptographic verification.
   - C2PA Content Credentials & AI watermark header detection.

4. **Web Source Trace & Provenance**:
   - Matches image hashes against sample web source repositories and prompt galleries.

5. **Cyber-Forensic Dashboard UI**:
   - Modern glassmorphism UI with neon indicators.
   - 1-click test samples toolbar (**Camera Photo**, **AI Portrait**, **Edited Image**).
   - Export report as JSON or copy summary.
   - History log saved in LocalStorage.

---

## 🚀 Quick Start (1-Click Launcher)

Run the Python launcher from project root:

```bash
python run_server.py
```

This will automatically:
1. Start the FastAPI backend at `http://127.0.0.1:8000`
2. Start the Frontend web server at `http://127.0.0.1:3000`
3. Launch `http://127.0.0.1:3000` in your web browser!

---

## 🛠️ Manual Launch

### Backend
```bash
cd backend
..\..\venv\Scripts\python.exe -m uvicorn main:app --reload --port 8000
```
- API Docs: `http://127.0.0.1:8000/docs`
- Health Check: `http://127.0.0.1:8000/health`

### Frontend
Open `frontend/index.html` directly in any web browser or serve with Live Server / `python -m http.server 3000`.
