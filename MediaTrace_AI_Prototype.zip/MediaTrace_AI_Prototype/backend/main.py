from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image
import io, hashlib

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    data = await file.read()
    img = Image.open(io.BytesIO(data))
    exif = bool(img.getexif())
    return {
        "filename": file.filename or "media.jpg",
        "score": 15.0 if exif else 82.0,
        "verdict": "Authentic Photo" if exif else "Likely AI-Generated",
        "format": img.format or "JPEG",
        "size": f"{img.width} × {img.height} px",
        "sha256": hashlib.sha256(data).hexdigest(),
        "signals": ["EXIF metadata present" if exif else "No EXIF metadata found"]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
