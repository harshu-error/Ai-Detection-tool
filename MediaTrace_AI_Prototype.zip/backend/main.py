from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image
from transformers import pipeline
import hashlib, io, os, logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mediatrace")

app = FastAPI(title="MediaTrace AI")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "..", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# ---------------------------------------------------------------------------
# AI MODEL
# Real pretrained deepfake image classifier (ViT, fine-tuned on real/fake
# images). Downloaded from Hugging Face the first time the server starts
# and cached locally afterwards. Replaces the old score-by-guess heuristic.
# Model card: https://huggingface.co/prithivMLmods/Deep-Fake-Detector-v2-Model
# ---------------------------------------------------------------------------
MODEL_NAME = "prithivMLmods/Deep-Fake-Detector-v2-Model"
_classifier = None


@app.on_event("startup")
def load_model():
    """Load the model once when the server starts, not on every request."""
    global _classifier
    logger.info("Loading deepfake detection model: %s ...", MODEL_NAME)
    _classifier = pipeline("image-classification", model=MODEL_NAME)
    logger.info("Model loaded.")


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": _classifier is not None}


def sha256(data: bytes):
    return hashlib.sha256(data).hexdigest()


def basic_forensics(image: Image.Image, data: bytes):
    r = {
        "format": image.format,
        "width": image.width,
        "height": image.height,
        "metadata_present": False,
        "sha256": sha256(data),
        "signals": [],
    }
    r["metadata_present"] = bool(image.getexif())
    r["signals"].append(
        "EXIF metadata detected" if r["metadata_present"]
        else "No EXIF metadata found (common in AI-generated / re-saved images)"
    )
    return r


def run_ai_model(image: Image.Image):
    """
    Run the real pretrained model and return a normalized result:
    { fake_probability: 0-100, label: str, raw: [...] }
    """
    if _classifier is None:
        raise RuntimeError("Model is not loaded yet.")

    # top_k=None returns scores for every class, not just the top prediction
    results = _classifier(image, top_k=None)

    fake_score = 0.0
    for r in results:
        if "fake" in r["label"].lower() or "deepfake" in r["label"].lower():
            fake_score = r["score"]
            break

    top = max(results, key=lambda r: r["score"])

    return {
        "fake_probability": round(fake_score * 100, 2),
        "predicted_label": top["label"],
        "raw_scores": [{"label": r["label"], "score": round(r["score"] * 100, 2)} for r in results],
    }


@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    data = await file.read()
    if not data:
        return {"error": "Empty file"}

    name = os.path.basename(file.filename or "media")
    with open(os.path.join(UPLOAD_DIR, name), "wb") as f:
        f.write(data)

    try:
        image = Image.open(io.BytesIO(data)).convert("RGB")
    except Exception:
        return {"error": "File is not a readable image. Please upload a JPG, PNG, or WEBP."}

    forensic = basic_forensics(image, data)

    try:
        ai_result = run_ai_model(image)
    except Exception as e:
        logger.exception("Model inference failed")
        return {"error": f"AI model inference failed: {e}"}

    score = ai_result["fake_probability"]

    if score >= 70:
        classification = "Likely AI-manipulated"
    elif score >= 40:
        classification = "Uncertain — manual review recommended"
    else:
        classification = "No strong manipulation signal"

    forensic["signals"].append(
        f"AI model prediction: {ai_result['predicted_label']} "
        f"({score}% deepfake confidence)"
    )

    return {
        "filename": name,
        "media_type": file.content_type,
        "ai_probability": score,
        "classification": classification,
        "model": {
            "name": MODEL_NAME,
            "raw_scores": ai_result["raw_scores"],
        },
        "forensics": forensic,
        "source_trace": {
            "status": "Prototype source index",
            "matches_found": 0,
            "message": "Connect a source database/reverse-search service here."
        }
    }
